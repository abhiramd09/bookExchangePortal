package portalBackend.Mutual.Book.Exchange.Portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MutualBookExchangePortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MutualBookExchangePortalApplication.class, args);
	}

}
