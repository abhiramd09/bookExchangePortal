package portalBackend.Mutual.Book.Exchange.Portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutualBookExchangePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
